//
//  MKShareDelegate.m
//  Share
//
//  Created by mac02 on 15/12/3.
//  Copyright © 2015年 ap04. All rights reserved.
//

#import "MKShareDelegate.h"

@implementation MKShareDelegate

@end
