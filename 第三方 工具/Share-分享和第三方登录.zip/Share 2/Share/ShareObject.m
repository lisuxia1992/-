
//
//  ShareObject.m
//  Share
//
//  Created by mac02 on 15/12/23.
//  Copyright © 2015年 ap04. All rights reserved.
//

#import "ShareObject.h"

@implementation ShareObject

@end
