//
//  ViewController.m
//  Share
//
//  Created by mac02 on 15/12/3.
//  Copyright © 2015年 ap04. All rights reserved.
//

#import "ViewController.h"
#import "ShareObject.h"
#import "MMShare.h"
#import <ShareSDK/ShareSDK.h>


@interface ViewController ()
@property (nonatomic, strong) ShareObject *shareObject;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.shareObject = [[ShareObject alloc]init];
    self.shareObject.content = @"时间美好的时刻不过与,就是简简单单的过着....";
    self.shareObject.title = @"从你的全世界路过";
    self.shareObject.url = @"http://www.maimeng.com";
    self.shareObject.imagUrl = @"http://pic18.nipic.com/20111205/8794023_210228183172_2.jpg";
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)qqAction:(id)sender {
    MMShare *share =  [MMShare sharedInstance];
    [share share:ShareTypeQQ shareObject:self.shareObject mediaType:SSPublishContentMediaTypeNews];
    
}

- (IBAction)logInWithQQ:(id)sender
{
    [ShareSDK getUserInfoWithType:ShareTypeQQSpace
                      authOptions:nil
                           result:^(BOOL result, id<ISSPlatformUser> userInfo, id<ICMErrorInfo> error) {
                               
                               if (result)
                               {
                                   NSLog(@"uid = %@",[userInfo uid]);
                                   NSLog(@"name = %@",[userInfo nickname]);
                                   NSLog(@"icon = %@",[userInfo profileImage]);
                                   
                               }
                               
                           }];
}

- (IBAction)wechatAction:(id)sender {
    MMShare *share =  [MMShare sharedInstance];
    [share share:ShareTypeWeixiSession shareObject:self.shareObject mediaType:SSPublishContentMediaTypeNews];
    
}

- (IBAction)logInWithWechat:(id)sender
{
    [ShareSDK getUserInfoWithType:ShareTypeWeixiFav
                      authOptions:nil
                           result:^(BOOL result, id<ISSPlatformUser> userInfo, id<ICMErrorInfo> error) {
                               
                               if (result)
                               {
                                   NSLog(@"uid = %@",[userInfo uid]);
                                   NSLog(@"name = %@",[userInfo nickname]);
                                   NSLog(@"icon = %@",[userInfo profileImage]);
                                   
                               }
                               
                           }];
}

- (IBAction)weiboAction:(id)sender {
 
    MMShare *share =  [MMShare sharedInstance];
    [share share:ShareTypeSinaWeibo shareObject:self.shareObject mediaType:SSPublishContentMediaTypeNews];
    
}

- (IBAction)logInWithWeibo:(id)sender
{
    [ShareSDK getUserInfoWithType:ShareTypeSinaWeibo
                      authOptions:nil
                           result:^(BOOL result, id<ISSPlatformUser> userInfo, id<ICMErrorInfo> error) {
                               
                               if (result)
                               {
                                   NSLog(@"uid = %@",[userInfo uid]);
                                   NSLog(@"name = %@",[userInfo nickname]);
                                   NSLog(@"icon = %@",[userInfo profileImage]);
                                   
                               }
                               
                           }];
}

- (IBAction)qqSpaceAction:(id)sender {
    MMShare *share =  [MMShare sharedInstance];
    [share share:ShareTypeQQSpace shareObject:self.shareObject mediaType:SSPublishContentMediaTypeNews];
    
}

- (IBAction)friendAction:(id)sender {
    
    MMShare *share =  [MMShare sharedInstance];
    [share share:ShareTypeWeixiTimeline shareObject:self.shareObject mediaType:SSPublishContentMediaTypeNews];
}

- (void)loginBtnClickHandler
{
    [ShareSDK getUserInfoWithType:ShareTypeSinaWeibo authOptions:nil result:^(BOOL result, id<ISSPlatformUser> userInfo, id<ICMErrorInfo> error) {
        NSLog(@"%d",result);
        if (result) {
            //成功登录后，判断该用户的ID是否在自己的数据库中。
            //如果有直接登录，没有就将该用户的ID和相关资料在数据库中创建新用户。
            [self reloadStateWithType:ShareTypeSinaWeibo];
        }
    }];
}

-(void)reloadStateWithType:(ShareType)type{
    //现实授权信息，包括授权ID、授权有效期等。
    //此处可以在用户进入应用的时候直接调用，如授权信息不为空且不过期可帮用户自动实现登录。
    id<ISSPlatformCredential> credential = [ShareSDK getCredentialWithType:type];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"TEXT_TIPS", @"提示")
                                                        message:[NSString stringWithFormat:
                                                                 @"uid = %@\ntoken = %@\nsecret = %@\n expired = %@\nextInfo = %@",
                                                                 [credential uid],
                                                                 [credential token],
                                                                 [credential secret],
                                                                 [credential expired],
                                                                 [credential extInfo]]
                                                       delegate:nil
                                              cancelButtonTitle:NSLocalizedString(@"TEXT_KNOW", @"知道了")
                                              otherButtonTitles:nil];
    [alertView show];
}


@end
