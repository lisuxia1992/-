//
//  ShareObject.h
//  Share
//
//  Created by mac02 on 15/12/23.
//  Copyright © 2015年 ap04. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface ShareObject : NSObject
@property (nonatomic, strong)NSString *title;
@property (nonatomic, strong)NSString *content;
@property (nonatomic, strong)NSString *imagUrl;
@property (nonatomic, strong)UIImage *shareImage;
@property (nonatomic, strong) NSString *url;
@end
