//
//  MMShare.h
//  Share
//
//  Created by mac02 on 15/12/23.
//  Copyright © 2015年 ap04. All rights reserved.
//



#import <Foundation/Foundation.h>
#import <ShareSDK/ShareSDK.h>
@class ShareObject;
typedef void (^resultBlock)(NSString *msg);
@interface MMShare : NSObject

+ (id)sharedInstance;
- (void)share:(ShareType)type shareObject:(ShareObject*)shareObject mediaType:(SSPublishContentMediaType)mediaType;
@end
