//
//  AppDelegate.m
//  Share
//
//  Created by mac02 on 15/12/3.
//  Copyright © 2015年 ap04. All rights reserved.
//

#import "AppDelegate.h"
#import <ShareSDK/ShareSDK.h>

//腾讯开放平台（对应QQ和QQ空间）SDK头文件
#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterface.h>

//微信SDK头文件
#import "WXApi.h"

//新浪微博SDK头文件
#import "WeiboSDK.h"


@interface AppDelegate ()

@end

@implementation AppDelegate

/*微博分享的回调方法*/
- (void)didReceiveWeiboResponse:(WBBaseResponse *)response
{
    if ([response isKindOfClass:WBSendMessageToWeiboResponse.class])
    {
        
        WBSendMessageToWeiboResponse* sendMessageToWeiboResponse = (WBSendMessageToWeiboResponse*)response;
        NSString* accessToken = [sendMessageToWeiboResponse.authResponse accessToken];
        if (accessToken)
        {
            self.wbtoken = accessToken;
        }
        NSString* userID = [sendMessageToWeiboResponse.authResponse userID];
        if (userID) {
            self.wbCurrentUserID = userID;
        }
        
//        [[NSNotificationCenter defaultCenter]postNotificationName:@"weiboShare" object:self userInfo:nil];
    }
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [self setAllShare];
    // Override point for customization after application launch.
    return YES;
}
- (void)setAllShare{
    
    [ShareSDK registerApp:@"c8cc96fcc890"];
  
    [WeiboSDK enableDebugMode:NO];
    [WeiboSDK registerApp:@"3697805899"];
    
 
    
    [ShareSDK importTencentWeiboClass:[WeiboSDK class]];
    [ShareSDK importWeChatClass:[WXApi class]];
    [ShareSDK importQQClass:[QQApiInterface class]
            tencentOAuthCls:[TencentOAuth class]];
//添加新浪微博应用 注册网址 http://open.weibo.com
[ShareSDK connectSinaWeiboWithAppKey:@"3697805899"
                           appSecret:@"287a30119c3af16d2e0de7bd200a9a20"
                         redirectUri:@"http://www.sharesdk.cn"];
//当使用新浪微博客户端分享的时候需要按照下面的方法来初始化新浪的平台
[ShareSDK  connectSinaWeiboWithAppKey:@"3697805899"
                            appSecret:@"287a30119c3af16d2e0de7bd200a9a20"
                          redirectUri:@"http://www.sharesdk.cn"
                          weiboSDKCls:[WeiboSDK class]];


//添加QQ空间应用  注册网址  http://connect.qq.com/intro/login/
[ShareSDK connectQZoneWithAppKey:@"1104929927"
                       appSecret:@"8CVg6E2ReJXKCwYy"
               qqApiInterfaceCls:[QQApiInterface class]
                 tencentOAuthCls:[TencentOAuth class]];

//添加QQ应用  注册网址   http://mobile.qq.com/api/
[ShareSDK connectQQWithQZoneAppKey:@"1104929927"
                 qqApiInterfaceCls:[QQApiInterface class]
                   tencentOAuthCls:[TencentOAuth class]];

//微信登陆的时候需要初始化
[ShareSDK connectWeChatWithAppId:@"wx4c528b647b78952e"
                       appSecret:@"d4624c36b6795d1d99dcf0547af5443d"
                       wechatCls:[WXApi class]];


    

    
}

//是否已加入handleOpenURL的处理方法，如果没有则添加如下代码：


- (BOOL)application:(UIApplication *)application
      handleOpenURL:(NSURL *)url
{
    return [ShareSDK handleOpenURL:url
                        wxDelegate:self];
}

- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation
{
    return [ShareSDK handleOpenURL:url
                 sourceApplication:sourceApplication
                        annotation:annotation
                        wxDelegate:self];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
