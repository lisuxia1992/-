//
//  MMShare.m
//  Share
//
//  Created by mac02 on 15/12/23.
//  Copyright © 2015年 ap04. All rights reserved.
//

#import "MMShare.h"

#import "WeiboSDK.h"
#import "ShareObject.h"
#import "AppDelegate.h"


static id _publishContent;
@interface MMShare()
{
     resultBlock _ResultdHandler;
}

@property (nonatomic, strong) ShareObject *shareObject;
@end
@implementation MMShare

+ (id)sharedInstance {
    static MMShare *m_instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        m_instance = [[self alloc] init];
    });
    
    return m_instance;
}



- (void)share:(ShareType)type shareObject:(ShareObject*)shareObject mediaType:(SSPublishContentMediaType)mediaType{
    
    self.shareObject = shareObject;
    
    id<ISSContent> publishContent = [ShareSDK content:self.shareObject.content
                                       defaultContent:nil
                                                image:[ShareSDK imageWithUrl:self.shareObject.imagUrl]
                                                title:self.shareObject.title
                                                  url:@"http://www.mmote.cn"
                                          description:nil
                                            mediaType:mediaType];
    
    
    if (type == ShareTypeSinaWeibo) {
        if(publishContent.mediaType==SSPublishContentMediaTypeNews ){
            [self shareWeibo];
            return;
        }
        else if (publishContent.mediaType==SSPublishContentMediaTypeImage){
            [self shareWeibo];
            return;
        }
    }
    

    
    [ShareSDK showShareViewWithType:type container:nil content:publishContent statusBarTips:YES authOptions:nil shareOptions:nil result:^(ShareType type, SSResponseState state, id<ISSPlatformShareInfo> statusInfo, id<ICMErrorInfo> error, BOOL end) {
       
        if (state == SSResponseStateSuccess)
        {
            NSLog(NSLocalizedString(@"TEXT_ShARE_SUC", @"分享成功"));
        }
        else if (state == SSResponseStateFail)
        {
            NSLog(NSLocalizedString(@"TEXT_ShARE_FAI", @"分享失败,错误码:%d,错误描述:%@"), [error errorCode], [error errorDescription]);
            NSLog(@"===%ld=====%@",(long)[error errorCode],[error errorDescription]);
           
        }
       
    }];
 
    
     

}

- (void)shareWeibo{
    
    AppDelegate *myDelegate =(AppDelegate*)[[UIApplication sharedApplication] delegate];
    
    
    WBAuthorizeRequest *authRequest = [WBAuthorizeRequest request];
    authRequest.redirectURI = @"http://www.mmote.cn";
    authRequest.scope = @"all";
    
    WBSendMessageToWeiboRequest *request = [WBSendMessageToWeiboRequest requestWithMessage:[self messageToShare] authInfo:authRequest access_token:myDelegate.wbtoken];
    
    [WeiboSDK sendRequest:request];
}


- (WBMessageObject *)messageToShare{

    WBMessageObject *message = [WBMessageObject message];
    
    if(self.shareObject.content.length==0){
      self.shareObject.content = @"";
    }
    if(self.shareObject.title.length==0){
       self.shareObject.title = @"";
    }
    if(self.shareObject.url.length==0){
        self.shareObject.url = @"";
    }
    if(self.shareObject.content.length>60){
        self.shareObject.content = [self.shareObject.content substringToIndex:59];
    }
    message.text = [NSString stringWithFormat:@"%@\n%@\n%@",self.shareObject.title,self.shareObject.content,self.shareObject.url];
    
     WBImageObject *image1 = [WBImageObject object];
    if (self.shareObject.imagUrl.length > 0) {
        image1.imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.shareObject.imagUrl]];
    }
    else {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"2" ofType:@"jpg"];
        image1.imageData = [NSData dataWithContentsOfFile:path];
    }
    
   message.imageObject = image1;
    return message;
}

@end
